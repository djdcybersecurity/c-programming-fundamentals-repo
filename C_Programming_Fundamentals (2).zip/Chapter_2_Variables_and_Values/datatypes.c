/* Exploring int, float, char, and double data types. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: datatypes.c\n");
    return 0;
}
