/* Using #define and const to declare constants. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: constants.c\n");
    return 0;
}
