/* Declaring and using variables in C. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: variables.c\n");
    return 0;
}
