/* Sorting an array using different algorithms. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: sorting.c\n");
    return 0;
}
