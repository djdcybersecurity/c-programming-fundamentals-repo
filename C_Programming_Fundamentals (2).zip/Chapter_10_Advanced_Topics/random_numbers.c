/* Generating random numbers using rand and srand. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: random_numbers.c\n");
    return 0;
}
