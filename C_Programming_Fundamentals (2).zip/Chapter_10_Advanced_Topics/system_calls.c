/* Interacting with the OS using system calls. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: system_calls.c\n");
    return 0;
}
