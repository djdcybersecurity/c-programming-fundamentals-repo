/* Using single-line and multi-line comments. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: comments.c\n");
    return 0;
}
