/* Exploring #include and #define directives. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: preprocessor_directives.c\n");
    return 0;
}
