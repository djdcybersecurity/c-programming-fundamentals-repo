/* Basic C program structure and execution. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: hello_world.c\n");
    return 0;
}
