/* Using recursive functions for calculations. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: recursion.c\n");
    return 0;
}
