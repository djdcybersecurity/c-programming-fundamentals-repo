/* Defining and calling functions in C. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: functions.c\n");
    return 0;
}
