/* Understanding function pointers. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: function_pointers.c\n");
    return 0;
}
