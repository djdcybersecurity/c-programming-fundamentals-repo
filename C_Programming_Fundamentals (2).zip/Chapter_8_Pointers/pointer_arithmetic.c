/* Performing arithmetic operations on pointers. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: pointer_arithmetic.c\n");
    return 0;
}
