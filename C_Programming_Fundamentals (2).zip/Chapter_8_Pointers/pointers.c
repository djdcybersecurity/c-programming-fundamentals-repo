/* Understanding basic pointers. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: pointers.c\n");
    return 0;
}
