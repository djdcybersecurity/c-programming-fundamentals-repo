/* Using malloc, calloc, realloc, and free. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: dynamic_memory.c\n");
    return 0;
}
