/* Reading and writing characters using getchar and putchar. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: char_io.c\n");
    return 0;
}
