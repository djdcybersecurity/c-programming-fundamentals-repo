/* Using common string functions like strlen, strcpy, strcat. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: string_functions.c\n");
    return 0;
}
