/* Modifying and manipulating strings in C. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: string_manipulation.c\n");
    return 0;
}
