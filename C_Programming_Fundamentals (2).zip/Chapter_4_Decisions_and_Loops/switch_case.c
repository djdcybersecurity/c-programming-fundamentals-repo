/* Using switch-case for multiple conditions. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: switch_case.c\n");
    return 0;
}
