/* Using for, while, and do-while loops. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: loops.c\n");
    return 0;
}
