/* Using if-else statements for decision making. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: if_else.c\n");
    return 0;
}
