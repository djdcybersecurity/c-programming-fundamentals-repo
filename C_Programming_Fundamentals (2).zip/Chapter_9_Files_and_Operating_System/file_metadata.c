/* Getting file information using stat functions. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: file_metadata.c\n");
    return 0;
}
