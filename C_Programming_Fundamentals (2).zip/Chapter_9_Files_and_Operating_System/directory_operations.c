/* Listing files in a directory. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: directory_operations.c\n");
    return 0;
}
