/* Reading from and writing to files. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: file_read_write.c\n");
    return 0;
}
