/* Declaring and using one-dimensional arrays. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: arrays.c\n");
    return 0;
}
