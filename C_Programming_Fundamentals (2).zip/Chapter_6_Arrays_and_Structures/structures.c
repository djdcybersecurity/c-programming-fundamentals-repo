/* Defining and using struct in C. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: structures.c\n");
    return 0;
}
