/* Working with multi-dimensional arrays. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: multi_dimensional_arrays.c\n");
    return 0;
}
