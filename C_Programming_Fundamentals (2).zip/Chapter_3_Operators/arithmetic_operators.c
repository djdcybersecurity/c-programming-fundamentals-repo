/* Performing basic arithmetic operations. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: arithmetic_operators.c\n");
    return 0;
}
