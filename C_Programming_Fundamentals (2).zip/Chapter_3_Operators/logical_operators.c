/* Using logical operators in decision making. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: logical_operators.c\n");
    return 0;
}
