/* Using relational operators for comparisons. */
#include <stdio.h>

int main() {
    printf("Hello, this is an example program for: relational_operators.c\n");
    return 0;
}
